# Ansible Nexus Deploy

Ansible playbooks and roles for managing AWS EC2 instances and deploying applications from Nexus Repository.

## Features

- 🚀 Deploy applications from Nexus Repository to EC2 instances
- 🔄 Rolling deployments with ALB integration
- ⏪ One-click rollback to previous releases
- 🏥 Comprehensive health checks
- 📦 EC2 instance provisioning and management
- 🔐 Support for multiple environments (dev, staging, production)
- 📊 Deployment notifications (Slack integration)

## Directory Structure

```
ansible-nexus-deploy/
├── ansible.cfg                 # Ansible configuration
├── requirements.yml            # Collection dependencies
├── inventory/
│   ├── dev.yml                # Development inventory
│   ├── staging.yml            # Staging inventory
│   └── production.yml         # Production inventory
├── group_vars/
│   ├── all.yml               # Global variables
│   ├── dev.yml               # Dev-specific variables
│   ├── staging.yml           # Staging-specific variables
│   └── production.yml        # Production-specific variables
├── roles/
│   ├── common/               # Common setup tasks
│   ├── java/                 # Java installation
│   ├── nexus-deploy/         # Nexus deployment logic
│   └── ec2-manage/           # EC2 management
└── playbooks/
    ├── deploy.yml            # Main deployment playbook
    ├── ec2-provision.yml     # EC2 provisioning
    ├── rollback.yml          # Rollback playbook
    └── health-check.yml      # Health check playbook
```

## Prerequisites

1. **Ansible 2.15+**
   ```bash
   pip install ansible
   ```

2. **AWS Collections**
   ```bash
   ansible-galaxy collection install -r requirements.yml
   ```

3. **AWS Credentials**
   Configure AWS credentials using one of:
   - Environment variables (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`)
   - AWS credentials file (`~/.aws/credentials`)
   - IAM instance profile

4. **SSH Access**
   - SSH key configured in `ansible.cfg`
   - Security groups allowing SSH access

## Quick Start

### 1. Install Dependencies

```bash
# Install Ansible collections
ansible-galaxy collection install -r requirements.yml

# Install Python dependencies
pip install boto3 botocore
```

### 2. Configure Variables

Edit `group_vars/all.yml`:
```yaml
# Nexus settings
nexus_url: "https://nexus.yourcompany.com"
nexus_repository: "maven-releases"
nexus_group_id: "com.yourcompany"
nexus_artifact_id: "your-app"

# Application settings
app_name: your-app
app_user: appuser
```

### 3. Deploy Application

```bash
# Deploy to dev
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml -e "deploy_version=1.0.0"

# Deploy to production with confirmation
ansible-playbook playbooks/deploy.yml -i inventory/production.yml -e "deploy_version=1.0.0"
```

## Playbook Usage

### Deploy Application

```bash
# Basic deployment
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml -e "deploy_version=1.0.0"

# Deploy to specific hosts
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml -e "deploy_version=1.0.0" --limit dev-app-01

# Deploy with rolling update (production)
ansible-playbook playbooks/deploy.yml -i inventory/production.yml \
  -e "deploy_version=1.0.0" \
  -e "enable_rolling_deploy=true" \
  -e "rolling_batch_size=1"

# Skip confirmation (CI/CD)
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml \
  -e "deploy_version=1.0.0" \
  -e "skip_confirmation=true"
```

### Provision EC2 Instances

```bash
# Provision new instances
ansible-playbook playbooks/ec2-provision.yml -e "env=dev" -e "provision_instances=true"

# Start existing instances
ansible-playbook playbooks/ec2-provision.yml -e "env=dev" -e "start_instances=true"

# Stop instances
ansible-playbook playbooks/ec2-provision.yml -e "env=dev" -e "stop_instances=true"

# Terminate instances (requires confirmation)
ansible-playbook playbooks/ec2-provision.yml -e "env=dev" -e "terminate_instances=true"
```

### Rollback

```bash
# Rollback to previous release
ansible-playbook playbooks/rollback.yml -i inventory/dev.yml

# Rollback to specific release
ansible-playbook playbooks/rollback.yml -i inventory/dev.yml -e "rollback_to=1704067200"
```

### Health Check

```bash
# Full health check
ansible-playbook playbooks/health-check.yml -i inventory/dev.yml

# Quick health check (service and HTTP only)
ansible-playbook playbooks/health-check.yml -i inventory/dev.yml --tags quick

# Fail on unhealthy (for CI/CD)
ansible-playbook playbooks/health-check.yml -i inventory/dev.yml -e "fail_on_unhealthy=true"
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `deploy_version` | Version to deploy | Required |
| `env` | Target environment | From inventory |
| `skip_confirmation` | Skip deployment confirmation | `false` |
| `enable_rolling_deploy` | Enable rolling deployment | `false` |
| `rolling_batch_size` | Hosts per batch | `1` |
| `rolling_pause` | Pause between batches (seconds) | `30` |

### Nexus Configuration

```yaml
# group_vars/all.yml
nexus_url: "https://nexus.company.com"
nexus_repository: "maven-releases"
nexus_group_id: "com.company"
nexus_artifact_id: "myapp"
nexus_packaging: "jar"
nexus_username: "deployer"
nexus_password: "{{ vault_nexus_password }}"
```

### EC2 Configuration

```yaml
# group_vars/dev.yml
ec2_instance_type: t3.small
ec2_ami_id: ami-0123456789abcdef0
ec2_key_name: dev-keypair
ec2_security_groups:
  - dev-app-sg
ec2_subnet_id: subnet-12345
ec2_instance_count: 2
ec2_volume_size: 20
```

## Secrets Management

Use Ansible Vault for sensitive data:

```bash
# Create vault file
ansible-vault create group_vars/vault.yml

# Edit vault file
ansible-vault edit group_vars/vault.yml

# Run playbook with vault
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml --ask-vault-pass

# Or use vault password file
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml --vault-password-file ~/.vault_pass
```

Example vault file:
```yaml
vault_nexus_password: "secret123"
vault_db_password: "dbsecret456"
```

## ALB Integration

For rolling deployments with Application Load Balancer:

```yaml
# group_vars/production.yml
enable_rolling_deploy: true
alb_target_group: "myapp-prod-tg"
rolling_batch_size: 1
rolling_pause: 30
```

The playbook will:
1. Deregister instance from ALB
2. Wait for connections to drain
3. Deploy new version
4. Run health checks
5. Register instance back to ALB
6. Wait for healthy status
7. Move to next batch

## Monitoring & Notifications

### Slack Notifications

```yaml
# group_vars/all.yml
slack_webhook_url: "https://hooks.slack.com/services/xxx/yyy/zzz"
```

### Health Check Endpoints

The playbook checks these endpoints:
- `http://localhost:8080/actuator/health` - Application health
- `http://localhost:8081/actuator/health` - Management port (optional)

## Troubleshooting

### Common Issues

1. **SSH Connection Failed**
   ```bash
   # Test SSH connectivity
   ansible all -i inventory/dev.yml -m ping
   ```

2. **Nexus Download Failed**
   ```bash
   # Test Nexus connectivity
   curl -u user:pass "https://nexus.company.com/service/rest/v1/search?repository=maven-releases&name=myapp"
   ```

3. **Service Won't Start**
   ```bash
   # Check service status
   ansible all -i inventory/dev.yml -m shell -a "systemctl status myapp"
   
   # Check logs
   ansible all -i inventory/dev.yml -m shell -a "tail -50 /var/log/myapp/myapp.log"
   ```

### Debug Mode

```bash
# Run with verbose output
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml -e "deploy_version=1.0.0" -vvv

# Check syntax
ansible-playbook playbooks/deploy.yml --syntax-check

# Dry run
ansible-playbook playbooks/deploy.yml -i inventory/dev.yml -e "deploy_version=1.0.0" --check
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with `ansible-lint`
5. Submit a pull request

## License

MIT License
