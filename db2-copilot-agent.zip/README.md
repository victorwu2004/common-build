# DB2 Copilot Agent

A natural-language → DB2 SQL agent built on the **GitHub Copilot SDK** (public
preview, April 2026). You ask a question in plain English; Copilot's agent
inspects your DB2 schema, writes a read-only query, runs it, self-corrects on
errors, and summarizes the answer.

## How it works

```
You ─"top 10 customers by revenue"─▶ Copilot SDK agent
                                          │  (planning + tool loop)
                          ┌───────────────┴───────────────┐
                          ▼                                ▼
                     get_schema  tool               run_query  tool
                     (SYSCAT.*)                      (read-only SELECT)
                          │                                │
                          └──────────────▶ DB2 ◀───────────┘
```

The Copilot SDK runs the agentic loop for you — you don't hand-roll prompt
chaining. You only provide two tools and a security gate.

- **`db2.py`** — connection, schema introspection (`SYSCAT.COLUMNS` +
  `SYSCAT.REFERENCES` for FKs), SQL validation, read-only execution.
- **`agent.py`** — registers `get_schema` / `run_query` as Copilot tools and
  enforces a **permission handler** that denies any non-read-only SQL.

## Two layers of safety

1. **DB2 read-only account** — the real guarantee. Connect with a user that has
   only SELECT privileges. Code filters are bypassable; database grants are not.
2. **Permission handler** — `make_permission_handler()` is called by the SDK
   *before every tool runs*. It denies `shell`/`write`/`url` tools entirely and
   re-validates every `run_query` SQL string as read-only before approving.

## Requirements

- Python **3.11+**
- A **GitHub Copilot subscription** (every prompt counts against your premium
  request quota) — *or* BYOK with your own OpenAI/Anthropic/Foundry key.
- Network access from this host to the Copilot service (and to your DB2 host).
  The Copilot CLI is bundled with the Python SDK automatically — no separate
  install needed.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # ibm_db wheels bundle the DB2 driver

cp .env.example .env                      # fill in DB2 + auth, then:
set -a && source .env && set +a           # export vars into your shell
```

Authenticate the Copilot SDK (pick one):
- Run the `copilot` CLI once and log in — the SDK reuses those credentials.
- Set `COPILOT_GITHUB_TOKEN` (or `GH_TOKEN` / `GITHUB_TOKEN`).
- Configure **BYOK** — see `docs/auth/byok.md` in the `github/copilot-sdk` repo.

## Run

```bash
python -m db2_agent.agent "Top 10 customers by total order value last year"
```

## Porting to other DB2 platforms

`db2.py` uses **DB2 LUW** catalog views (`SYSCAT.*`). For:
- **z/OS**: `SYSIBM.SYSCOLUMNS`, `SYSIBM.SYSRELS`
- **DB2 for i (AS/400)**: `QSYS2.SYSCOLUMNS`, `QSYS2.SYSREFCST`

Swap the queries in `get_schema()` accordingly.

## Notes for enterprise / locked-down networks

- `ibm_db` on RHEL may need `gcc` and `LD_LIBRARY_PATH` pointing at the bundled
  `clidriver` if `import ibm_db` fails.
- Schema **metadata** (table/column names) is sent to the model. Query result
  rows are returned to the agent so it can summarize — confirm this is allowed
  under your data-handling policy, or use BYOK with a self-hosted/approved model
  endpoint to keep traffic in-network.
- For large databases, don't dump the whole schema — retrieve only relevant
  tables (e.g. embed table docs and vector-search the question) to keep prompts
  small and accuracy high.

> The Copilot SDK is in **public preview** — functional for development/testing,
> not yet positioned for production. Pin the version and check release notes
> between upgrades.
