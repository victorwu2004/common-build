"""
╔══════════════════════════════════════════════════════════════════════════════╗
║      GitHub Copilot SDK Test App with GPT-5.3-Codex                          ║
║                                                                              ║
║  Tests:                                                                      ║
║    1. SDK installation and authentication                                    ║
║    2. Connection to GitHub Copilot API                                       ║
║    3. Simple chat with GPT-5.3-Codex                                         ║
║    4. Code generation task                                                   ║
║    5. Multi-turn conversation                                                ║
║    6. Streaming response                                                     ║
║    7. Agent mode (if available)                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

PREREQUISITES:
    1. Active GitHub Copilot subscription (Pro, Pro+, Business, or Enterprise)
    2. Python 3.10+ installed
    3. GitHub CLI authenticated via: copilot auth login
       OR provide GITHUB_TOKEN environment variable

USAGE:
    pip install -r requirements.txt
    copilot auth login              # If not already done
    python copilot_test.py          # Run all tests
    python copilot_test.py --test 3 # Run a specific test
"""

import os
import sys
import argparse
import asyncio
import logging
from datetime import datetime
from typing import Optional, List, Dict

# ═════════════════════════════════════════════════════════════════════════════
# LOGGING SETUP
# ═════════════════════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("COPILOT-TEST")


# ═════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═════════════════════════════════════════════════════════════════════════════

class Config:
    # Model: GPT-5.3-Codex is OpenAI's agentic coding model
    # Released Feb 5, 2026 - base model for Copilot Business/Enterprise
    MODEL = "gpt-5.3-codex"
    
    # Alternative models you can swap to:
    # "gpt-5.5"           - Latest model (7.5x premium)
    # "gpt-5.3-codex"     - Default Codex model (1x cost)
    # "claude-opus-4.6"   - Anthropic's model in Copilot
    # "claude-sonnet-4.6" - Anthropic's faster model
    
    # Token: from env or copilot CLI login
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "") or os.getenv("COPILOT_GITHUB_TOKEN", "")
    
    # Use CLI login if no token
    USE_CLI_LOGIN = not bool(GITHUB_TOKEN)


# ═════════════════════════════════════════════════════════════════════════════
# CHECK SDK INSTALLATION
# ═════════════════════════════════════════════════════════════════════════════

def check_sdk_installed():
    """Verify the Copilot SDK is installed"""
    try:
        from copilot import CopilotClient
        log.info("✓ GitHub Copilot SDK installed")
        return True
    except ImportError:
        log.error("✗ GitHub Copilot SDK not installed")
        log.error("  Install: pip install github-copilot-sdk")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 1: AUTHENTICATION
# ═════════════════════════════════════════════════════════════════════════════

async def test_authentication():
    """Test 1: Verify authentication works"""
    print("\n" + "═" * 70)
    print("  TEST 1: AUTHENTICATION")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        if Config.GITHUB_TOKEN:
            print(f"  Using token authentication (GITHUB_TOKEN env var)")
            client = CopilotClient(
                github_token=Config.GITHUB_TOKEN,
                use_logged_in_user=False,
            )
        else:
            print(f"  Using CLI authentication (copilot auth login)")
            client = CopilotClient()  # Uses CLI credentials
        
        await client.start()
        print(f"  ✓ Client started successfully")
        
        # Get version/status info
        try:
            status = await client.get_status()
            print(f"  ✓ SDK Version: {status.get('version', 'unknown')}")
            print(f"  ✓ User: {status.get('user', 'authenticated')}")
        except AttributeError:
            print(f"  ✓ Authentication verified (status endpoint not available)")
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Authentication failed: {e}")
        print(f"\n  Troubleshooting:")
        print(f"    1. Run: copilot auth login")
        print(f"    2. OR set GITHUB_TOKEN environment variable")
        print(f"    3. Ensure you have an active Copilot subscription")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 2: LIST AVAILABLE MODELS
# ═════════════════════════════════════════════════════════════════════════════

async def test_list_models():
    """Test 2: List models available in your Copilot plan"""
    print("\n" + "═" * 70)
    print("  TEST 2: AVAILABLE MODELS")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        client = CopilotClient() if Config.USE_CLI_LOGIN else CopilotClient(
            github_token=Config.GITHUB_TOKEN, use_logged_in_user=False
        )
        await client.start()
        
        try:
            models = await client.list_models()
            print(f"  ✓ Available models ({len(models)}):")
            for model in models:
                model_id = model.get('id') if isinstance(model, dict) else str(model)
                marker = "← TARGET" if Config.MODEL in model_id else ""
                print(f"    - {model_id}  {marker}")
        except AttributeError:
            # Fallback if list_models not supported
            print(f"  ⚠ list_models() not supported in this SDK version")
            print(f"  Known models in Copilot:")
            print(f"    - gpt-5.3-codex   (base, 1x cost)")
            print(f"    - gpt-5.5         (premium, 7.5x cost)")
            print(f"    - claude-opus-4.6")
            print(f"    - claude-sonnet-4.6")
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 3: SIMPLE CHAT
# ═════════════════════════════════════════════════════════════════════════════

async def test_simple_chat():
    """Test 3: Simple one-shot chat with GPT-5.3-Codex"""
    print("\n" + "═" * 70)
    print(f"  TEST 3: SIMPLE CHAT WITH {Config.MODEL}")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        client = CopilotClient() if Config.USE_CLI_LOGIN else CopilotClient(
            github_token=Config.GITHUB_TOKEN, use_logged_in_user=False
        )
        await client.start()
        
        session = await client.create_session(
            session_id=f"test-chat-{datetime.now().strftime('%H%M%S')}",
            model=Config.MODEL,
        )
        
        prompt = "What is 2 + 2? Reply in exactly one word."
        print(f"  Prompt: {prompt}")
        print(f"  Sending to {Config.MODEL}...")
        
        response = await session.send_and_wait(prompt=prompt)
        
        print(f"\n  ✓ Response received:")
        print(f"    {response}")
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 4: CODE GENERATION
# ═════════════════════════════════════════════════════════════════════════════

async def test_code_generation():
    """Test 4: Code generation task (Codex's strength)"""
    print("\n" + "═" * 70)
    print("  TEST 4: CODE GENERATION TASK")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        client = CopilotClient() if Config.USE_CLI_LOGIN else CopilotClient(
            github_token=Config.GITHUB_TOKEN, use_logged_in_user=False
        )
        await client.start()
        
        session = await client.create_session(
            session_id=f"test-code-{datetime.now().strftime('%H%M%S')}",
            model=Config.MODEL,
        )
        
        prompt = """Write a Python function that:
1. Takes a list of integers
2. Returns the sum of all even numbers
3. Includes a docstring with one example

Reply with ONLY the function, no explanations."""
        
        print(f"  Prompt: {prompt[:80]}...")
        print(f"  Sending to {Config.MODEL}...")
        
        response = await session.send_and_wait(prompt=prompt)
        
        print(f"\n  ✓ Code generated:")
        print(f"  " + "─" * 66)
        for line in response.split("\n"):
            print(f"  │ {line}")
        print(f"  " + "─" * 66)
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 5: MULTI-TURN CONVERSATION
# ═════════════════════════════════════════════════════════════════════════════

async def test_multi_turn():
    """Test 5: Multi-turn conversation (memory across turns)"""
    print("\n" + "═" * 70)
    print("  TEST 5: MULTI-TURN CONVERSATION")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        client = CopilotClient() if Config.USE_CLI_LOGIN else CopilotClient(
            github_token=Config.GITHUB_TOKEN, use_logged_in_user=False
        )
        await client.start()
        
        session = await client.create_session(
            session_id=f"test-multi-{datetime.now().strftime('%H%M%S')}",
            model=Config.MODEL,
        )
        
        turns = [
            "My favorite color is purple.",
            "What is my favorite color?",
            "Now write a one-line CSS rule using my favorite color for background.",
        ]
        
        for i, prompt in enumerate(turns, 1):
            print(f"\n  Turn {i}:")
            print(f"    User: {prompt}")
            response = await session.send_and_wait(prompt=prompt)
            print(f"    AI:   {response}")
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 6: STREAMING RESPONSE
# ═════════════════════════════════════════════════════════════════════════════

async def test_streaming():
    """Test 6: Stream response token-by-token"""
    print("\n" + "═" * 70)
    print("  TEST 6: STREAMING RESPONSE")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        client = CopilotClient() if Config.USE_CLI_LOGIN else CopilotClient(
            github_token=Config.GITHUB_TOKEN, use_logged_in_user=False
        )
        await client.start()
        
        session = await client.create_session(
            session_id=f"test-stream-{datetime.now().strftime('%H%M%S')}",
            model=Config.MODEL,
        )
        
        prompt = "Count slowly from 1 to 5, each number on its own line."
        print(f"  Prompt: {prompt}")
        print(f"\n  Streaming response:")
        print(f"  " + "─" * 66)
        
        try:
            async for chunk in session.send_stream(prompt=prompt):
                if hasattr(chunk, 'content'):
                    print(chunk.content, end="", flush=True)
                elif hasattr(chunk, 'text'):
                    print(chunk.text, end="", flush=True)
                else:
                    print(chunk, end="", flush=True)
            print()
        except AttributeError:
            # Fallback - send_stream not available
            print(f"  ⚠ Streaming not supported in this SDK version, using regular send:")
            response = await session.send_and_wait(prompt=prompt)
            print(f"  {response}")
        
        print(f"  " + "─" * 66)
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST 7: AGENT MODE
# ═════════════════════════════════════════════════════════════════════════════

async def test_agent_mode():
    """Test 7: Agent mode - GPT-5.3-Codex's specialty (file ops, planning)"""
    print("\n" + "═" * 70)
    print("  TEST 7: AGENT MODE (file operations)")
    print("═" * 70)
    
    from copilot import CopilotClient
    
    try:
        client = CopilotClient() if Config.USE_CLI_LOGIN else CopilotClient(
            github_token=Config.GITHUB_TOKEN, use_logged_in_user=False
        )
        await client.start()
        
        # Create a workspace folder for the test
        test_dir = os.path.abspath("./copilot_test_workspace")
        os.makedirs(test_dir, exist_ok=True)
        
        session = await client.create_session(
            session_id=f"test-agent-{datetime.now().strftime('%H%M%S')}",
            model=Config.MODEL,
            workspace=test_dir,
        )
        
        prompt = """Create a file called hello.py in the current workspace that:
1. Prints "Hello from GPT-5.3-Codex!" 
2. Then prints today's date
Just create the file. Don't run it."""
        
        print(f"  Workspace: {test_dir}")
        print(f"  Prompt: {prompt[:80]}...")
        print(f"  Running agent...")
        
        response = await session.send_and_wait(prompt=prompt)
        
        print(f"\n  ✓ Agent response:")
        print(f"    {response[:300]}...")
        
        # Check if file was created
        hello_file = os.path.join(test_dir, "hello.py")
        if os.path.exists(hello_file):
            print(f"\n  ✓ File created: {hello_file}")
            print(f"  Contents:")
            with open(hello_file) as f:
                for line in f:
                    print(f"    │ {line.rstrip()}")
        else:
            print(f"\n  ⚠ File not created (agent may not have file access)")
        
        await client.stop()
        return True
        
    except Exception as e:
        print(f"  ✗ Failed: {e}")
        return False


# ═════════════════════════════════════════════════════════════════════════════
# TEST RUNNER
# ═════════════════════════════════════════════════════════════════════════════

TESTS = {
    1: ("Authentication",         test_authentication),
    2: ("List Available Models",  test_list_models),
    3: ("Simple Chat",            test_simple_chat),
    4: ("Code Generation",        test_code_generation),
    5: ("Multi-turn Conversation", test_multi_turn),
    6: ("Streaming Response",     test_streaming),
    7: ("Agent Mode",             test_agent_mode),
}


async def run_all_tests():
    """Run all tests and print summary"""
    print("\n" + "█" * 70)
    print("  GITHUB COPILOT SDK TEST SUITE")
    print(f"  Model: {Config.MODEL}")
    print(f"  Auth:  {'Token' if Config.GITHUB_TOKEN else 'CLI Login'}")
    print("█" * 70)
    
    if not check_sdk_installed():
        return
    
    results = {}
    for test_id, (name, test_fn) in TESTS.items():
        try:
            success = await test_fn()
            results[test_id] = (name, success)
        except KeyboardInterrupt:
            print("\n  Interrupted by user")
            break
        except Exception as e:
            log.error(f"Test {test_id} crashed: {e}")
            results[test_id] = (name, False)
    
    # Print summary
    print("\n" + "█" * 70)
    print("  TEST RESULTS SUMMARY")
    print("█" * 70)
    passed = sum(1 for _, success in results.values() if success)
    total = len(results)
    
    for test_id, (name, success) in results.items():
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"  Test {test_id}: {name:<35} {status}")
    
    print("─" * 70)
    print(f"  Total: {passed}/{total} tests passed")
    print("█" * 70 + "\n")


async def run_single_test(test_id: int):
    """Run a single test by ID"""
    if not check_sdk_installed():
        return
    
    if test_id not in TESTS:
        print(f"Invalid test ID: {test_id}")
        print(f"Available tests:")
        for tid, (name, _) in TESTS.items():
            print(f"  {tid}. {name}")
        return
    
    name, test_fn = TESTS[test_id]
    print(f"\nRunning Test {test_id}: {name}\n")
    success = await test_fn()
    print(f"\nResult: {'✓ PASSED' if success else '✗ FAILED'}\n")


# ═════════════════════════════════════════════════════════════════════════════
# MAIN
# ═════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="GitHub Copilot SDK Test App with GPT-5.3-Codex",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
EXAMPLES:
  python copilot_test.py                  # Run all 7 tests
  python copilot_test.py --test 3         # Run only test 3 (Simple Chat)
  python copilot_test.py --model gpt-5.5  # Use a different model
  python copilot_test.py --list-tests     # Show available tests

AUTHENTICATION:
  Option 1 (CLI login - recommended):
    $ copilot auth login

  Option 2 (Environment variable):
    $ export GITHUB_TOKEN="gho_your_token_here"
        """
    )
    
    parser.add_argument(
        "--test", "-t", type=int, choices=list(TESTS.keys()),
        help="Run a specific test by number (1-7)"
    )
    parser.add_argument(
        "--model", "-m", type=str, default=Config.MODEL,
        help=f"Model to use (default: {Config.MODEL})"
    )
    parser.add_argument(
        "--list-tests", action="store_true",
        help="List available tests and exit"
    )
    
    args = parser.parse_args()
    
    if args.list_tests:
        print("\nAvailable tests:")
        for tid, (name, _) in TESTS.items():
            print(f"  {tid}. {name}")
        print()
        return
    
    # Override model if specified
    if args.model:
        Config.MODEL = args.model
    
    try:
        if args.test:
            asyncio.run(run_single_test(args.test))
        else:
            asyncio.run(run_all_tests())
    except KeyboardInterrupt:
        print("\nInterrupted")
        sys.exit(0)


if __name__ == "__main__":
    main()
