# GitHub Copilot SDK Test App with GPT-5.3-Codex

A Python sample application that tests the GitHub Copilot SDK with GPT-5.3-Codex, OpenAI's agentic coding model.

## What This Tests

| # | Test | What It Verifies |
|---|------|------------------|
| 1 | Authentication | SDK auth via CLI or token |
| 2 | List Available Models | Which models your plan can use |
| 3 | Simple Chat | Basic prompt → response |
| 4 | Code Generation | Codex's specialty |
| 5 | Multi-turn Conversation | Session memory across turns |
| 6 | Streaming Response | Token-by-token streaming |
| 7 | Agent Mode | File operations, planning |

## Prerequisites

### 1. Active Copilot Subscription

GPT-5.3-Codex requires one of:
- **Copilot Pro** ($10/month)
- **Copilot Pro+** ($39/month)
- **Copilot Business** ($19/user/month)
- **Copilot Enterprise** ($39/user/month)

GPT-5.3-Codex is the **base model** for Business/Enterprise (free tier, 1x cost).

### 2. Python 3.10+

```bash
python --version
```

## Setup

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This installs `github-copilot-sdk` which auto-bundles the Copilot CLI.

### Step 2: Authenticate

Choose ONE of these methods:

#### Option A: CLI Login (Recommended)

```bash
copilot auth login
```

This opens a browser for GitHub OAuth device flow.

#### Option B: Environment Variable

```bash
# Linux/Mac
export GITHUB_TOKEN="gho_your_token_here"

# Windows PowerShell
$env:GITHUB_TOKEN = "gho_your_token_here"

# Windows CMD
set GITHUB_TOKEN=gho_your_token_here
```

Get your token from: https://github.com/settings/tokens

Required scopes:
- `read:user`
- `copilot` (if available)

## Usage

### Run All Tests

```bash
python copilot_test.py
```

Output:
```
██████████████████████████████████████████████████████████████████████
  GITHUB COPILOT SDK TEST SUITE
  Model: gpt-5.3-codex
  Auth:  CLI Login
██████████████████████████████████████████████████████████████████████

══════════════════════════════════════════════════════════════════════
  TEST 1: AUTHENTICATION
══════════════════════════════════════════════════════════════════════
  Using CLI authentication (copilot auth login)
  ✓ Client started successfully
  ✓ SDK Version: 1.2.0
  ✓ User: yourusername

... (more tests) ...

██████████████████████████████████████████████████████████████████████
  TEST RESULTS SUMMARY
██████████████████████████████████████████████████████████████████████
  Test 1: Authentication                      ✓ PASS
  Test 2: List Available Models               ✓ PASS
  Test 3: Simple Chat                         ✓ PASS
  Test 4: Code Generation                     ✓ PASS
  Test 5: Multi-turn Conversation             ✓ PASS
  Test 6: Streaming Response                  ✓ PASS
  Test 7: Agent Mode                          ✓ PASS
──────────────────────────────────────────────────────────────────────
  Total: 7/7 tests passed
██████████████████████████████████████████████████████████████████████
```

### Run a Specific Test

```bash
python copilot_test.py --test 3  # Just simple chat
python copilot_test.py --test 4  # Just code generation
python copilot_test.py --test 7  # Just agent mode
```

### List Available Tests

```bash
python copilot_test.py --list-tests
```

### Use a Different Model

```bash
# Try GPT-5.5 (7.5x cost premium)
python copilot_test.py --model gpt-5.5

# Try Claude Opus 4.6 in Copilot
python copilot_test.py --model claude-opus-4.6

# Try Claude Sonnet 4.6
python copilot_test.py --model claude-sonnet-4.6
```

## Available Models in GitHub Copilot

| Model | Cost Multiplier | Notes |
|-------|----------------|-------|
| **gpt-5.3-codex** | 1x | Default base model, agentic coding |
| gpt-5.5 | 7.5x | Latest GPT, most capable |
| gpt-5.3-codex-spark | 1x | Faster/cheaper variant |
| claude-opus-4.6 | varies | Anthropic's flagship |
| claude-sonnet-4.6 | varies | Anthropic's faster model |

## Troubleshooting

### "ModuleNotFoundError: No module named 'copilot'"

```bash
pip install github-copilot-sdk
```

### "Authentication failed"

1. Check your subscription is active
2. Re-authenticate: `copilot auth logout && copilot auth login`
3. Verify token has correct scopes

### "Model not available"

GPT-5.3-Codex must be enabled by your org admin (Business/Enterprise).

For Pro plans:
- Pro: gpt-5.3-codex available
- Free: limited models

Check your model availability at: https://github.com/settings/copilot

### "Premium request quota exceeded"

Each Copilot plan has monthly premium request limits:

| Plan | Premium Requests |
|------|------------------|
| Pro | 50/month |
| Pro+ | 500/month |
| Business | 300/user/month |
| Enterprise | 1000/user/month |

GPT-5.3-Codex uses 1x multiplier; GPT-5.5 uses 7.5x.

### Test 7 (Agent Mode) Fails

Agent mode requires:
1. Write access to the workspace folder
2. SDK version ≥ 1.0.0
3. Pro+ / Business / Enterprise plan

## How GPT-5.3-Codex Compares

GPT-5.3-Codex is OpenAI's agentic coding model:
- Released February 5, 2026
- Long-term support through February 4, 2027
- Designed for: planning, tool use, multi-step coding tasks
- Best for: refactoring, debugging, implementation from specs

vs. other models:
- **vs GPT-5.5**: Cheaper (1x vs 7.5x), slightly less powerful, faster for code
- **vs Claude Opus 4.6**: Competitive; GPT-5.3 is 25% faster on benchmarks
- **vs GPT-4.1**: Significantly better at agentic tasks, multi-step workflows

## File Structure

```
copilot_test_app/
├── copilot_test.py       # Main test app
├── requirements.txt      # Python deps
├── README.md             # This file
└── copilot_test_workspace/  # Created during Test 7
    └── hello.py          # Generated by GPT-5.3-Codex
```

## What's Next?

After running these tests successfully, you can:

1. **Build your own Copilot integrations** - Use the SDK to add AI to your apps
2. **Customize agents** - Create specialized agents with system prompts
3. **Integrate MCP servers** - Connect Copilot to your tools
4. **Use BYOK** - Bring your own OpenAI/Anthropic key for billing flexibility

See [GitHub Copilot SDK docs](https://docs.github.com/en/copilot/how-tos/copilot-sdk) for more.

## License

MIT - Use freely for testing and learning.
