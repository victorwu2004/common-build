#!/bin/bash
# GitHub Copilot SDK Test Runner

set -e
cd "$(dirname "${BASH_SOURCE[0]}")"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   GitHub Copilot SDK Test - GPT-5.3-Codex                 ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Python detection
if command -v python3 &> /dev/null; then
    PYTHON="python3"
elif command -v python &> /dev/null; then
    PYTHON="python"
else
    echo -e "${RED}ERROR: Python not found${NC}"
    exit 1
fi

# Install deps
echo -e "${GREEN}Installing dependencies...${NC}"
$PYTHON -m pip install -q -r requirements.txt 2>/dev/null || {
    echo "Installing..."
    $PYTHON -m pip install -r requirements.txt
}

# Check authentication
if [ -z "$GITHUB_TOKEN" ]; then
    echo -e "${YELLOW}No GITHUB_TOKEN env var found.${NC}"
    echo -e "${YELLOW}Will use CLI authentication (copilot auth login)${NC}"
    
    if ! command -v copilot &> /dev/null; then
        echo -e "${YELLOW}Copilot CLI not found in PATH${NC}"
        echo -e "${YELLOW}It should be installed automatically with the SDK${NC}"
    fi
fi

echo ""
$PYTHON copilot_test.py "$@"
