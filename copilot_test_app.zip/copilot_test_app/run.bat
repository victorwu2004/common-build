@echo off
cd /d "%~dp0"

echo.
echo ============================================================
echo   GitHub Copilot SDK Test - GPT-5.3-Codex
echo ============================================================
echo.

where python >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Python not found
    exit /b 1
)

echo Installing dependencies...
python -m pip install -q -r requirements.txt

if "%GITHUB_TOKEN%"=="" (
    echo.
    echo No GITHUB_TOKEN found. Will use CLI authentication.
    echo If not logged in, run: copilot auth login
    echo.
)

python copilot_test.py %*
